# Checker Dilbar Ali

Starter Android app for checking BISP/8171 eligibility through the official portal.

## Included
- App name: Checker Dilbar Ali
- Urdu interface
- 8171 eligibility button
- Opens the official BISP 8171 website
- No private CNIC/payment database is stored by this starter app

## Important
This project does not claim direct access to BISP payment databases. Any payment/eligibility result should come from an authorized official source.
