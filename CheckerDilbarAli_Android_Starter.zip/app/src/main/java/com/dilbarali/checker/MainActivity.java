package com.dilbarali.checker;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
    private static final String OFFICIAL_8171 = "https://8171.bisp.gov.pk/";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(32, 48, 32, 32);
        root.setBackgroundColor(Color.rgb(6, 26, 58));

        TextView title = new TextView(this);
        title.setText("Checker Dilbar Ali");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 20, 0, 12);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("بینظیر انکم سپورٹ پروگرام\n8171 اہلیت چیک");
        subtitle.setTextColor(Color.WHITE);
        subtitle.setTextSize(19);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, 36);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        Button check = new Button(this);
        check.setText("8171 اہلیت چیک کریں");
        check.setTextSize(18);
        check.setOnClickListener(v ->
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(OFFICIAL_8171))));
        root.addView(check, new LinearLayout.LayoutParams(-1, 64));

        TextView note = new TextView(this);
        note.setText("\nاہلیت کی معلومات سرکاری 8171 پورٹل سے حاصل کریں۔\nاپنا CNIC صرف سرکاری پورٹل پر درج کریں۔");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(15);
        note.setGravity(Gravity.CENTER);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }
}
